<?php
/**
 * Silence is golden.
 *
 * @package Redux Framework
 */

echo null;
