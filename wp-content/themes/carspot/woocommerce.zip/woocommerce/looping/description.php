<div class="short-description">
 <h2><?php echo esc_html__('Quick Overview','carspot'); ?></h2>
<p><?php the_excerpt(); ?></p>                    
</div>
 <div class="clearfix"></div>